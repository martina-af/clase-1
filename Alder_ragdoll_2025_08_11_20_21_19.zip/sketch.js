function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background(99,109,170);
}